﻿# DSC configuration for Firewall
# 

configuration AddFirewallRuleToNewGroup
{
   
    Import-DSCResource -ModuleName xNetworking

    Node localhost
    {
        xFirewall Firewall
        {
            Name                  = "NotePadFirewallRule"
            DisplayName           = "Firewall Rule for Notepad.exe"
            DisplayGroup          = "NotePad Firewall Rule Group"
            Ensure                = "Present"
            Access                = "Block"
            Description           = "Firewall Rule for Notepad.exe"  
            ApplicationPath       = "c:\windows\system32\notepad.exe"
        }
    }
 }